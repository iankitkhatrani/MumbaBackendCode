self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "27286c01cc3f35d5575ce62362e33b3d",
    "url": "/index.html"
  },
  {
    "revision": "ca707f5bb2533db8e9af",
    "url": "/static/css/0.3e68da18.chunk.css"
  },
  {
    "revision": "3e325985c7f13b99c880",
    "url": "/static/css/13.2e947bf2.chunk.css"
  },
  {
    "revision": "f452719764c25710c442",
    "url": "/static/css/14.0b0054da.chunk.css"
  },
  {
    "revision": "02d806800813a86722a8",
    "url": "/static/css/16.834d426e.chunk.css"
  },
  {
    "revision": "bacd6a58b58c40a070e1",
    "url": "/static/css/main.dfb41827.chunk.css"
  },
  {
    "revision": "ca707f5bb2533db8e9af",
    "url": "/static/js/0.737a36f9.chunk.js"
  },
  {
    "revision": "783f14fa45b10e088e68f98251448010",
    "url": "/static/js/0.737a36f9.chunk.js.LICENSE.txt"
  },
  {
    "revision": "850abe69cc70edce732e",
    "url": "/static/js/1.3bf1cd07.chunk.js"
  },
  {
    "revision": "9264cb4050e8259a1fb9",
    "url": "/static/js/10.1a3e5dfc.chunk.js"
  },
  {
    "revision": "3e325985c7f13b99c880",
    "url": "/static/js/13.35055033.chunk.js"
  },
  {
    "revision": "f2fce78a0a0a19c2649c6b24e52364fd",
    "url": "/static/js/13.35055033.chunk.js.LICENSE.txt"
  },
  {
    "revision": "f452719764c25710c442",
    "url": "/static/js/14.52e03ea8.chunk.js"
  },
  {
    "revision": "91129439ce485112c906",
    "url": "/static/js/15.1ccb945e.chunk.js"
  },
  {
    "revision": "02d806800813a86722a8",
    "url": "/static/js/16.cef6bd08.chunk.js"
  },
  {
    "revision": "184d75891cb9af11f1a9",
    "url": "/static/js/17.1a1cdd5c.chunk.js"
  },
  {
    "revision": "f99ba7c29536b2be0d66",
    "url": "/static/js/18.5b2469c1.chunk.js"
  },
  {
    "revision": "8f86978a9d4debf1b06d",
    "url": "/static/js/19.2d6fe9d0.chunk.js"
  },
  {
    "revision": "15b1b594ae16ab67b96d",
    "url": "/static/js/2.46e9cc08.chunk.js"
  },
  {
    "revision": "159e2b338822acefde69",
    "url": "/static/js/20.7c63d72e.chunk.js"
  },
  {
    "revision": "6481ec95cb32942fe21b",
    "url": "/static/js/21.8ae49fa4.chunk.js"
  },
  {
    "revision": "e8a19933efcbdb0298d1",
    "url": "/static/js/22.d8afebbf.chunk.js"
  },
  {
    "revision": "b7b96908c494f876d52a",
    "url": "/static/js/23.cc8fcb0d.chunk.js"
  },
  {
    "revision": "b9286edab2b6e3c092d1",
    "url": "/static/js/24.e8bf84c8.chunk.js"
  },
  {
    "revision": "bd14eb1089d313efd491",
    "url": "/static/js/25.7dd7503e.chunk.js"
  },
  {
    "revision": "c0a351001411a512ad82",
    "url": "/static/js/26.db4e8040.chunk.js"
  },
  {
    "revision": "ff70c4f4be0685ad602a",
    "url": "/static/js/27.72879f57.chunk.js"
  },
  {
    "revision": "c80c7ea0bb3f24815010",
    "url": "/static/js/28.8c5e41de.chunk.js"
  },
  {
    "revision": "fc035e932a124549e3a2",
    "url": "/static/js/29.f32d9832.chunk.js"
  },
  {
    "revision": "b32f85d91aaba090f9d2",
    "url": "/static/js/3.19305ee0.chunk.js"
  },
  {
    "revision": "eed44795abe9d0f12cb7",
    "url": "/static/js/30.4fd555f9.chunk.js"
  },
  {
    "revision": "a3c63d6dded0295a6897",
    "url": "/static/js/31.58a0f058.chunk.js"
  },
  {
    "revision": "1a6f759209f4e5936fad",
    "url": "/static/js/32.ecc926d2.chunk.js"
  },
  {
    "revision": "2ef293760e0b953a0ff5",
    "url": "/static/js/33.76026f4c.chunk.js"
  },
  {
    "revision": "19716ce95788e2b86ed7",
    "url": "/static/js/34.00828868.chunk.js"
  },
  {
    "revision": "157f2c1e46819ecb8609",
    "url": "/static/js/35.a56316aa.chunk.js"
  },
  {
    "revision": "3998b076eba5fdfe4ab3",
    "url": "/static/js/36.836a8b00.chunk.js"
  },
  {
    "revision": "da3df660879a80850354",
    "url": "/static/js/37.df1de01b.chunk.js"
  },
  {
    "revision": "8cf16251c824637bd0c9",
    "url": "/static/js/38.b615e6b3.chunk.js"
  },
  {
    "revision": "b57049887504088c6774",
    "url": "/static/js/39.8e35eba6.chunk.js"
  },
  {
    "revision": "2fefb6783031fe1e801f",
    "url": "/static/js/4.776b8b59.chunk.js"
  },
  {
    "revision": "307524047ed481fd82f6",
    "url": "/static/js/40.ad201f14.chunk.js"
  },
  {
    "revision": "f0662ecd0f3b98fc0182",
    "url": "/static/js/41.dd8fe099.chunk.js"
  },
  {
    "revision": "1e871ea2f98bbc512d33",
    "url": "/static/js/42.3a9b92f1.chunk.js"
  },
  {
    "revision": "a5cfb048c5c7442d2d03",
    "url": "/static/js/43.7d85ebf7.chunk.js"
  },
  {
    "revision": "521b50e795fff31e8040",
    "url": "/static/js/44.1a8a8be9.chunk.js"
  },
  {
    "revision": "2d677cc452aa076424f4",
    "url": "/static/js/45.c4691d68.chunk.js"
  },
  {
    "revision": "658822001ff2eb07b3b8",
    "url": "/static/js/46.8d34c77b.chunk.js"
  },
  {
    "revision": "11fe1ce1a0faf7f19fd0",
    "url": "/static/js/47.9621e8b5.chunk.js"
  },
  {
    "revision": "fce497f4d3807e12b74f",
    "url": "/static/js/48.dbe75d15.chunk.js"
  },
  {
    "revision": "2c654924d009a00a2397",
    "url": "/static/js/49.685c62c1.chunk.js"
  },
  {
    "revision": "0c2c63af2b831d222db8",
    "url": "/static/js/5.546a71cf.chunk.js"
  },
  {
    "revision": "07a5229938cefe389bb7",
    "url": "/static/js/50.29496261.chunk.js"
  },
  {
    "revision": "6857b14a6b95a2ec8a91",
    "url": "/static/js/51.5dcacd8f.chunk.js"
  },
  {
    "revision": "5a38c63ef3353d400c6e",
    "url": "/static/js/52.9f1900c6.chunk.js"
  },
  {
    "revision": "6386fd14cfac67de993c",
    "url": "/static/js/53.169516b6.chunk.js"
  },
  {
    "revision": "37b7fc3cfabf56f4ae99",
    "url": "/static/js/54.517b9f31.chunk.js"
  },
  {
    "revision": "2dd84a8c47958e3c05c5",
    "url": "/static/js/55.711ea295.chunk.js"
  },
  {
    "revision": "f1cb19b6c804fd96ecca",
    "url": "/static/js/56.897062b4.chunk.js"
  },
  {
    "revision": "35dc84e0341e9ed00adf",
    "url": "/static/js/57.f41516eb.chunk.js"
  },
  {
    "revision": "92e0567825020470604d",
    "url": "/static/js/58.3d0348d0.chunk.js"
  },
  {
    "revision": "749a06852ed300dfd3b3",
    "url": "/static/js/59.ef765e6d.chunk.js"
  },
  {
    "revision": "df5b8b1bbf6cdbdaa70c",
    "url": "/static/js/6.16899caf.chunk.js"
  },
  {
    "revision": "93035673e262334190c1",
    "url": "/static/js/60.918960dc.chunk.js"
  },
  {
    "revision": "bf17f673dbd95b64b54e",
    "url": "/static/js/61.1f207d59.chunk.js"
  },
  {
    "revision": "2b9826ccf633a5b3e89b",
    "url": "/static/js/62.9eecd5b9.chunk.js"
  },
  {
    "revision": "de07e5f35fd8129e9258",
    "url": "/static/js/63.89217185.chunk.js"
  },
  {
    "revision": "f9fd4224225574eac0a9",
    "url": "/static/js/64.4519d111.chunk.js"
  },
  {
    "revision": "ec742f9ea8d13fb9cc00",
    "url": "/static/js/65.d81d0123.chunk.js"
  },
  {
    "revision": "3098626c4bdef874ac23",
    "url": "/static/js/66.8418756b.chunk.js"
  },
  {
    "revision": "2aaf8ac4672077e16038",
    "url": "/static/js/67.53274671.chunk.js"
  },
  {
    "revision": "a77beee59eb4c2f8749e",
    "url": "/static/js/68.f45f8a0c.chunk.js"
  },
  {
    "revision": "4d33c1fd552f1d30b224",
    "url": "/static/js/69.ed11ab79.chunk.js"
  },
  {
    "revision": "849223b0846cc1f524bf",
    "url": "/static/js/7.e1e8e206.chunk.js"
  },
  {
    "revision": "277fa9babd6015320163",
    "url": "/static/js/70.7f5d7702.chunk.js"
  },
  {
    "revision": "cdbc41e4cbd5f019e902",
    "url": "/static/js/71.0276bb03.chunk.js"
  },
  {
    "revision": "a3e180b640646a8f127a",
    "url": "/static/js/72.8dd4cd97.chunk.js"
  },
  {
    "revision": "9f5171f0bef4b3adc1b3",
    "url": "/static/js/73.06ba0ebe.chunk.js"
  },
  {
    "revision": "a369b67b15eb990d9275",
    "url": "/static/js/74.32e401f1.chunk.js"
  },
  {
    "revision": "9db31d3c99bef9e6847b",
    "url": "/static/js/75.b8d1b45b.chunk.js"
  },
  {
    "revision": "f51283c26f6afa029589",
    "url": "/static/js/76.7d1964aa.chunk.js"
  },
  {
    "revision": "1f557e14ab45298e1c3d",
    "url": "/static/js/77.46985aff.chunk.js"
  },
  {
    "revision": "d85d2811670b8dd45d82",
    "url": "/static/js/78.667234ea.chunk.js"
  },
  {
    "revision": "7c8d31b834830648530d",
    "url": "/static/js/79.497e7b98.chunk.js"
  },
  {
    "revision": "5fed63fec329491c8647",
    "url": "/static/js/8.158c5358.chunk.js"
  },
  {
    "revision": "ab4f5ff5260be9a759ea",
    "url": "/static/js/80.5c78dd66.chunk.js"
  },
  {
    "revision": "5d2f1c76cffdd7079234",
    "url": "/static/js/81.b9624b07.chunk.js"
  },
  {
    "revision": "112f4149500bf19c4346",
    "url": "/static/js/82.3020358a.chunk.js"
  },
  {
    "revision": "8ecf7725bb9d289d88a2",
    "url": "/static/js/9.94143ca5.chunk.js"
  },
  {
    "revision": "bacd6a58b58c40a070e1",
    "url": "/static/js/main.6dfc17c7.chunk.js"
  },
  {
    "revision": "ace4db796eafe6fe5532",
    "url": "/static/js/runtime-main.b22286fc.js"
  },
  {
    "revision": "35c254f1bc43c56e8cfae5d817be8d5f",
    "url": "/static/media/1.35c254f1.jpg"
  },
  {
    "revision": "e3ecc43c35f3e4d97bf187e8fccd9965",
    "url": "/static/media/2.e3ecc43c.jpg"
  },
  {
    "revision": "ed038830eaa255c8c2d58ed871d54f97",
    "url": "/static/media/3.ed038830.jpg"
  },
  {
    "revision": "98c972f61e9885a0ceeaa243aacfa7d6",
    "url": "/static/media/4.98c972f6.jpg"
  },
  {
    "revision": "3c60e090c7128eb1c57e03cabe091c05",
    "url": "/static/media/404.3c60e090.png"
  },
  {
    "revision": "11911410dca2de148f30954eb2fd5eab",
    "url": "/static/media/arrow_left.11911410.svg"
  },
  {
    "revision": "8ef6a08cdc1154920165680a4edde771",
    "url": "/static/media/arrow_right.8ef6a08c.svg"
  },
  {
    "revision": "035047178ed13101f120c47e1f36b043",
    "url": "/static/media/avatar.03504717.png"
  },
  {
    "revision": "ad04b412ac89dfa2f4fb8734d387cad0",
    "url": "/static/media/faq.ad04b412.jpg"
  },
  {
    "revision": "3d2fa2e544004aef2ea641698b715af6",
    "url": "/static/media/feather.3d2fa2e5.woff"
  },
  {
    "revision": "6a750f0119ba9c8ab8a994a4796599a6",
    "url": "/static/media/feather.6a750f01.ttf"
  },
  {
    "revision": "7975b0a027366be768319ee2f9e1734e",
    "url": "/static/media/feather.7975b0a0.svg"
  },
  {
    "revision": "931c9e74d0b20947054bfe6a5b74a838",
    "url": "/static/media/feather.931c9e74.eot"
  },
  {
    "revision": "b17d26ffb93bddee5e782ca657ae7efd",
    "url": "/static/media/kasino-logo.b17d26ff.png"
  },
  {
    "revision": "e45627865b1429eb3f10a2b6c19541bd",
    "url": "/static/media/parallax-4.e4562786.jpg"
  }
]);